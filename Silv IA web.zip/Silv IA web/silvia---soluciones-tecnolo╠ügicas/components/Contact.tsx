
import React, { useState } from 'react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';
import { Card } from './ui/Card';
import { Button } from './ui/Button';

export const Contact = React.forwardRef<HTMLElement>((props, ref) => {
  useScrollAnimation();
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [status, setStatus] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Here you would typically send the form data to a server
    console.log('Form submitted:', formData);
    setStatus('¡Gracias por tu mensaje! Nos pondremos en contacto pronto.');
    setFormData({ name: '', email: '', message: '' });
  };

  return (
    <section id="contact" ref={ref} className="py-20 sm:py-28">
      <div className="text-center mb-16 fade-in-section">
        <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-glow-cyan">Hablemos de tu Proyecto</h2>
        <p className="mt-4 text-lg text-slate-400 max-w-3xl mx-auto">
          ¿Listo para automatizar el futuro de tu empresa? Contáctanos para una asesoría gratuita.
        </p>
      </div>

      <div className="max-w-4xl mx-auto fade-in-section">
        <Card>
          <div className="grid md:grid-cols-2 gap-10">
            <div>
              <h3 className="text-2xl font-bold text-white mb-4">Envíanos un mensaje</h3>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-slate-400 mb-1">Nombre</label>
                  <input type="text" name="name" id="name" required value={formData.name} onChange={handleChange} className="w-full bg-slate-800/50 border border-slate-700 rounded-md p-2 focus:ring-cyan-500 focus:border-cyan-500 transition"/>
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-slate-400 mb-1">Correo Electrónico</label>
                  <input type="email" name="email" id="email" required value={formData.email} onChange={handleChange} className="w-full bg-slate-800/50 border border-slate-700 rounded-md p-2 focus:ring-cyan-500 focus:border-cyan-500 transition"/>
                </div>
                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-slate-400 mb-1">Mensaje</label>
                  <textarea name="message" id="message" rows={4} required value={formData.message} onChange={handleChange} className="w-full bg-slate-800/50 border border-slate-700 rounded-md p-2 focus:ring-cyan-500 focus:border-cyan-500 transition"></textarea>
                </div>
                <Button type="submit" variant="primary" className="w-full">Enviar Mensaje</Button>
              </form>
              {status && <p className="mt-4 text-center text-green-400">{status}</p>}
            </div>
            <div className="flex flex-col justify-center">
              <h3 className="text-2xl font-bold text-white mb-4">Otras formas de contacto</h3>
              <div className="space-y-4">
                  <a href="https://wa.me/521667XXXXXXX" target="_blank" rel="noopener noreferrer" className="flex items-center p-4 rounded-lg bg-slate-800/50 hover:bg-slate-800/80 transition border border-slate-700">
                    <p className="font-semibold text-white">WhatsApp</p>
                  </a>
                   <a href="mailto:contacto@silvia.com" className="flex items-center p-4 rounded-lg bg-slate-800/50 hover:bg-slate-800/80 transition border border-slate-700">
                    <p className="font-semibold text-white">Correo Electrónico</p>
                  </a>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </section>
  );
});
