
import React from 'react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';
import { Card } from './ui/Card';
import { BrainCircuitIcon, CodeIcon, ServerIcon, SmartHomeIcon, ShoppingCartIcon } from './icons';

const servicesData = [
  {
    icon: <BrainCircuitIcon className="w-8 h-8 text-cyan-400" />,
    title: 'Inteligencia Artificial & Automatización',
    items: [
      'Chatbots inteligentes para atención al cliente',
      'Automatización de procesos administrativos y operativos',
      'Análisis y tratamiento de datos con Python',
      'Generación automática de reportes en PDF',
      'Visualización y graficación de información',
      'Soluciones basadas en datos para toma de decisiones',
    ],
  },
  {
    icon: <CodeIcon className="w-8 h-8 text-cyan-400" />,
    title: 'Desarrollo de Software & SaaS',
    items: [
      'Desarrollo Backend y Frontend',
      'Aplicaciones web empresariales',
      'Plataformas SaaS',
      'APIs e integraciones',
      'Sistemas a la medida',
    ],
  },
  {
    icon: <ServerIcon className="w-8 h-8 text-cyan-400" />,
    title: 'Infraestructura, Redes y Telecomunicaciones',
    items: [
      'Diseño y administración de redes',
      'Configuración de nodos y site',
      'Cableado estructurado',
      'Telefonía IP y conmutadores',
      'CRM para Call Centers',
    ],
  },
  {
    icon: <SmartHomeIcon className="w-8 h-8 text-cyan-400" />,
    title: 'Cámaras y Casas Inteligentes',
    items: [
      'Instalación de CCTV',
      'Automatización de hogares y oficinas',
      'Control de iluminación, clima, TV, albercas y más',
      'Integración de dispositivos inteligentes',
    ],
  },
   {
    icon: <ShoppingCartIcon className="w-8 h-8 text-cyan-400" />,
    title: 'Venta de Tecnología',
    items: [
      'Equipos de red',
      'Seguridad y videovigilancia',
      'Soluciones empresariales',
    ],
  },
];

const Checkmark = () => (
    <svg className="w-5 h-5 text-cyan-400 mr-3 flex-shrink-0" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 2C6.49 2 2 6.49 2 12C2 17.51 6.49 22 12 22C17.51 22 22 17.51 22 12C22 6.49 17.51 2 12 2ZM10.44 16.5L6.5 12.56L7.91 11.15L10.44 13.68L16.09 8.03L17.5 9.44L10.44 16.5Z" fill="currentColor"/>
    </svg>
);


export const Services = React.forwardRef<HTMLElement>((props, ref) => {
  useScrollAnimation();

  return (
    <section id="services" ref={ref} className="py-20 sm:py-28">
      <div className="text-center mb-16 fade-in-section">
        <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-glow-cyan">Nuestros Servicios</h2>
        <p className="mt-4 text-lg text-slate-400 max-w-3xl mx-auto">
          Ofrecemos un ecosistema completo de soluciones tecnológicas para llevar tu empresa al siguiente nivel.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {servicesData.map((service, index) => (
          <div key={service.title} className="fade-in-section" style={{ transitionDelay: `${index * 150}ms` }}>
            <Card className="h-full flex flex-col">
              <div className="flex items-center mb-4">
                <div className="p-3 rounded-lg bg-cyan-500/10 mr-4">{service.icon}</div>
                <h3 className="text-xl font-bold text-white">{service.title}</h3>
              </div>
              <ul className="space-y-3 mt-4 text-slate-400">
                {service.items.map((item) => (
                  <li key={item} className="flex items-start">
                    <Checkmark />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </Card>
          </div>
        ))}
      </div>
    </section>
  );
});
