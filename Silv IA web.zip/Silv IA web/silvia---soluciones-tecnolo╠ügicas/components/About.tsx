
import React from 'react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';
import { EyeIcon, TargetIcon } from './icons';
import { Card } from './ui/Card';

export const About = React.forwardRef<HTMLElement>((props, ref) => {
  useScrollAnimation();

  return (
    <section id="about" ref={ref} className="py-20 sm:py-28">
      <div className="text-center mb-16 fade-in-section">
        <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-glow-cyan">¿Qué es SilvIA?</h2>
        <p className="mt-4 text-lg text-slate-400 max-w-3xl mx-auto">
          SilvIA es una empresa de soluciones tecnológicas integrales que combina Inteligencia Artificial, automatización, desarrollo de software e infraestructura tecnológica, adaptándose a cualquier necesidad empresarial, desde negocios locales hasta grandes empresas.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <div className="fade-in-section" style={{ transitionDelay: '200ms' }}>
          <Card>
            <div className="flex items-center mb-4">
              <div className="p-3 rounded-full bg-cyan-500/10 mr-4 border border-cyan-500/30">
                <TargetIcon className="w-6 h-6 text-cyan-400" />
              </div>
              <h3 className="text-2xl font-bold text-white">Misión</h3>
            </div>
            <p className="text-slate-400">
              Impulsar a empresas y negocios mediante soluciones tecnológicas inteligentes, integrales y personalizadas, utilizando inteligencia artificial, automatización, desarrollo de software e infraestructura tecnológica para optimizar procesos, reducir costos y mejorar la toma de decisiones.
            </p>
          </Card>
        </div>
        <div className="fade-in-section" style={{ transitionDelay: '400ms' }}>
          <Card>
            <div className="flex items-center mb-4">
               <div className="p-3 rounded-full bg-cyan-500/10 mr-4 border border-cyan-500/30">
                <EyeIcon className="w-6 h-6 text-cyan-400" />
              </div>
              <h3 className="text-2xl font-bold text-white">Visión</h3>
            </div>
            <p className="text-slate-400">
              Convertirnos en una empresa referente en soluciones con inteligencia artificial y tecnología integral en Sinaloa y México, reconocida por nuestra capacidad de adaptación, innovación constante y por transformar problemas complejos en soluciones eficientes, seguras y escalables.
            </p>
          </Card>
        </div>
      </div>
    </section>
  );
});