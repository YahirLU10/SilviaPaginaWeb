import React from "react";
import { useScrollAnimation } from "../hooks/useScrollAnimation";
import { Card } from "./ui/Card";

import empresasImage from "../src/para-empresas.webp";
import localesImage from "../src/para-locales.webp";
import callCenterImage from "../src/para-call-center.webp";

const solutionsData = [
  {
    title: "Para Empresas",
    description:
      "Optimizamos operaciones a gran escala, desde la automatización de flujos de trabajo hasta el desarrollo de software empresarial robusto y seguro.",
    image: empresasImage,
  },
  {
    title: "Para Negocios Locales",
    description:
      "Digitalizamos y potenciamos tu negocio con chatbots para atención al cliente, sistemas de gestión a medida y una infraestructura tecnológica sólida.",
    image: localesImage,
  },
  {
    title: "Para Call Centers",
    description:
      "Implementamos CRM avanzados, telefonía IP y automatizaciones con IA para maximizar la eficiencia de tus agentes y la satisfacción del cliente.",
    image: callCenterImage,
  },
];

export const Solutions = React.forwardRef<HTMLElement>((props, ref) => {
  useScrollAnimation();

  return (
    <section id="solutions" ref={ref} className="py-20 sm:py-28">
      <div className="text-center mb-16 fade-in-section">
        <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-glow-cyan">
          Soluciones a tu Medida
        </h2>
        <p className="mt-4 text-lg text-slate-400 max-w-3xl mx-auto">
          Adaptamos nuestra tecnología para resolver los desafíos específicos de
          cada sector.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {solutionsData.map((solution, index) => (
          <div
            key={solution.title}
            className="fade-in-section"
            style={{ transitionDelay: `${index * 150}ms` }}
          >
            <Card className="h-full flex flex-col overflow-hidden p-0">
              <img
                src={solution.image}
                alt={solution.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-6 flex flex-col flex-grow">
                <h3 className="text-xl font-bold text-white mb-2">
                  {solution.title}
                </h3>
                <p className="text-slate-400 flex-grow">
                  {solution.description}
                </p>
              </div>
            </Card>
          </div>
        ))}
      </div>
    </section>
  );
});
