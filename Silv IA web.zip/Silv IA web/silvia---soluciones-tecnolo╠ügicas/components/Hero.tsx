
import React from 'react';
import { Button } from './ui/Button';

export const Hero = () => {
  return (
    <section id="home" className="py-24 sm:py-32 md:py-40 text-center">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl sm:text-5xl md:text-7xl font-black tracking-tighter text-white">
          <span className="text-cyan-400">Automatizamos el presente,</span> Construimos el futuro
        </h1>
        <p className="mt-6 text-lg sm:text-xl text-slate-400 max-w-2xl mx-auto">
          Soluciones tecnológicas integrales para llevar tu negocio al siguiente nivel con Inteligencia Artificial y automatización.
        </p>
        <div className="mt-10 flex items-center justify-center">
          <Button asLink href="#contact" variant="primary" className="w-full sm:w-auto">
            Agenda una Asesoría
          </Button>
        </div>
      </div>
    </section>
  );
};