declare module "*.webp" {
  const src: string;
  export default src;
}
